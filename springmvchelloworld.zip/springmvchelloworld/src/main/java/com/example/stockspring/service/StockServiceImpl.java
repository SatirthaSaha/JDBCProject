package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.stockspring.dao.StockDao;
import com.example.stockspring.dao.StockDaoImpl;
import com.example.stockspring.model.Stock;

@Service
public class StockServiceImpl implements StockService{
	
	private StockDao stockDao= new StockDaoImpl();

	@Override
	public boolean insertStock(Stock stock) throws SQLException {
		// TODO Auto-generated method stub
		return stockDao.insertStock(stock);
	}

	

	@Override
	public List<Stock> getAllStock() throws SQLException, Exception {
		// TODO Auto-generated method stub
		return stockDao.getAllStock();
	}

}
